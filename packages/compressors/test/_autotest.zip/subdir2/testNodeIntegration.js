﻿var fs = NativeModule.require('fs');
fs.isDir('d:\\')

var util = NativeModule.require('util');
util.inspect(process.env);


util.format('aa %s', 'asa');
util.inspect(
  {a: 1, 
  b:"ss", 
  c: function(){}
})

var a = NativeModule.require('assert');
a.ok(false, 'yes')

process.moduleLoadList

var path = NativeModule.require('path');
path.resolve('C:/aa.txt');
path.resolve(process.execPath, '..', '..', 'lib', 'node');



for (a in _process)
  toLog(a)

Error.stack()



var path = NativeModule.require('path');
var isWindows = process.platform === 'win32';

  if (isWindows) {
    var homeDir = process.env.USERPROFILE;
  } else {
    var homeDir = process.env.HOME;
  }

  var paths = [path.resolve(process.execPath, '..', '..', 'lib', 'node')];

  if (homeDir) {
    paths.unshift(path.resolve(homeDir, '.node_libraries'));
    paths.unshift(path.resolve(homeDir, '.node_modules'));
  }

  if (process.env['NODE_PATH']) {
    var splitter = isWindows ? ';' : ':';
    paths = process.env['NODE_PATH'].split(splitter).concat(paths);
  }

paths.slice(0);
  modulePaths = paths;

// clone as a read-only copy, for introspection.
Module.globalPaths = modulePaths.slice(0);

var util = NativeModule.require('util');
util.inspect(process.argv);
util.inspect(process.env);

util.inspect(NativeModule)

var l = new TubList();
l.val = 1;
util.inspect(l);


var Module = NativeModule.require('module');
Module._load('D:/SVN/UB/trunk/06-Source/release/test.js', null, true);
Module._load('./test.js', null, true);

console.log('yes %o', [{a: 1}])
console.time('aa');
var r, Module;
for(let i=0; i<5000000; i++) {
  r = NativeModule.require('util');
  Module = NativeModule.require('module');
}
r.inspect(process.argv);
console.timeEnd('aa')
console.log('aa %s', 'a'); 1

conn.runCustom('runSQL', 'select * from uba_user');
conn.lastResponse

process.env.USERPROFILE

var path = NativeModule.require('path')
path.resolve('..\\aa.js');
path.resolve(process.execPath, '..', '..', 'lib', 'node')
path.resolve(process.execPath, '.', 'lib')
console.log('aa')


writeFile('d:\\aa.txt', 'hello!', true);



console.log('aaa %s', 'asas')




var assert = require('assert');
var fs = require('fs');
var path = require('path');

assert.equal(true, 0 === 1);


var v = loadFile('D:\\SVN\\M3\\trunk\\06-Source\\release\\rus.txt')
v
1


var cli = new THTTPClient('localhost', '888', false);
cli.method = 'GET';
cli.request('m3ora/index-dev.html', '')
cli.responseText


Ext.Loader.setConfig({
    enabled: true,
    paths: {
        'UB': './modules/UB'
    }
});
мфк сщтт = Ext.require('UB.Connection');

var csv = require('csv.js');
csv.parseCSV('1,3,4\r\n4,5,6')
console.log(process)


var cli = new THTTPClient('hotline.ua', '', false);
cli.method = 'GET';
cli.request('/', '')
cli.responseText.length


var _ = require('underscore.js')

var l = 100000, v;
var buf = new TubBuffer(l);
buf[32768] = 128
for (let i = 0; i<l; i++){
//   console.log(i);
   buf[i] = i % 255;
}

var Buffer = require('./lib/buffer');
for (let i = 0; i<l; i++){
   v = buf[i];
   if (v !== i % 255) console.error('<>');
}

var buf_1 = new Int8Array(l);
for (let i = 0; i<l; i++){
   buf_1[i] = i % 255;
}

for (let i = 0; i<l; i++){
   v = buf_1[i];
  if (v !== i % 255) console.error('(' +  v + '<>' + i % 255);
}

